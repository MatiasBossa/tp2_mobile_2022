package com.example.bossa_matias_tp2;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.provider.Telephony;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Date;

public class MessageReader extends Service{
    private boolean loop = true;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Thread worker = new Thread(new Reader());
        worker.start();
        return START_STICKY;

    }

    @Override
    public void onDestroy(){
        loop = false;
        Log.d("output","Service has Stopped");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private class Reader implements Runnable{
        private String body, date, address;

        @Override
        public void run(){
            while(loop){
                Uri messageUri = Uri.parse("content://sms");
                try{
                Cursor cursor_message = getContentResolver().query(messageUri, null, null ,null, null);

                if(cursor_message.getCount() == 0){
                    throw new Exception("ERROR - NO HAVE MESSAGES");
                }

                int totalMessageToRead = cursor_message.getCount() > 5 ? 5 : cursor_message.getCount();
                cursor_message.moveToFirst();

                for (int i = 0; i < totalMessageToRead; i++){
                    date = cursor_message.getString(cursor_message.getColumnIndexOrThrow(Telephony.Sms.DATE));
                    body = cursor_message.getString(cursor_message.getColumnIndexOrThrow(Telephony.Sms.BODY));
                    address = cursor_message.getString(cursor_message.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));

                    Log.d("Message", "Date: " + new Date(Long.parseLong(date)) + " - Address: " + address + " - Body: " + body);
                    cursor_message.moveToNext();
                }

                Thread.sleep(9000);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }
}